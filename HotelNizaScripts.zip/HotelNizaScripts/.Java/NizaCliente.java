// FINAL PRACTICE
// NizaCliente.java
// Code for servlet associated to client area
// by Telmo Martinez, Carolina Nolasco and Viktor Odriozola

import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

@WebServlet("/NizaCliente")
public class NizaCliente extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public NizaCliente() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// Obtain information from session
		HttpSession session = request.getSession(false);
		Cliente nizacliente = (Cliente)session.getAttribute("nizasession");
		
		// Obtain pressed button
		String view_mod = request.getParameter("viewmod");
		String book = request.getParameter("book");
		String login = request.getParameter("login");
		
		if (login !=null ) // If user requested to go back to login
		{
			// Redirect user to login
			response.sendRedirect("NizaLogin.html");
		}
		else if (view_mod != null) // If user requested to view information
		{
			try
			{
				// Register driver and connect to DB
				Class.forName("com.mysql.cj.jdbc.Driver");
				String URL="jdbc:mysql://localhost:3306/PFinal";
				Connection conn = DriverManager.getConnection(URL,"root","scd");
				
				// Create statement
				Statement st = conn.createStatement();
				
				// Select free rooms
				String sql = "SELECT roomID FROM RoomsNiza WHERE userID = " + nizacliente.id + ";"; 
				ResultSet rs = st.executeQuery(sql);
				
				// Show user session information
				PrintWriter toClient = response.getWriter();
				toClient.println("<html>");
				toClient.println("<title>Niza Hotel</title>");
				toClient.println("<body>");
				toClient.println("<h1>Client Information</h1>");
				toClient.println("<h4>You username and password are displayed below</h4>");
				toClient.println("<hr></hr>");
				toClient.println("<BR><BR>		Username: " + nizacliente.user);
				toClient.println("<BR>		Password: " + nizacliente.pass + "<BR><BR>");
				toClient.println("<h4> The rooms you have booked are shown on the following list</h4>");
				toClient.println("<hr></hr>");
				
				// Display the booked rooms by the client
				while (rs.next()) // Go through entire result set and print rooms
				{
					int room = rs.getInt("roomID");
					toClient.println("Room: "+ room +"<BR>");
				}
				toClient.println("<BR>");
				
				// Give user opportunity to modify, redirect in this case to Modify page
				toClient.println("<form action=\"http://localhost:8080/PracticaFinalSCD/NizaModify.html\" method=\"POST\">");
				toClient.println("<input type=submit name=mod value=\"Change Username / Password\">");
				toClient.println("</form>");
				// Give user opportunity to go back, redirect in this case to Client Area page
				toClient.println("<form action=\"http://localhost:8080/PracticaFinalSCD/NizaCliente.html\" method=\"POST\">");
				toClient.println("<input type=submit name=return value=\"Return\">");
				toClient.println("</form>");
				toClient.println("</body>");
				toClient.println("</html>");
				toClient.close();
				// Close statements, result sets and DB connection
				st.close();
				rs.close();
				conn.close();
			}
			catch(Exception e){ e.printStackTrace(); }
			
		}
		else if (book != null) // If user requested to book a room
		{
			try
			{
				// Register driver and connect to DB
				Class.forName("com.mysql.cj.jdbc.Driver");
				String URL="jdbc:mysql://localhost:3306/PFinal";
				Connection conn = DriverManager.getConnection(URL,"root","scd");
				
				// Create statement
				Statement st = conn.createStatement();
				
				// Select free rooms
				String sql = "SELECT * FROM RoomsNiza WHERE availability = 0;"; 
				ResultSet rs = st.executeQuery(sql);
				
				if(!rs.next()) // No free rooms found
				{
					// Inform user and redirect to client area
					PrintWriter toClient = response.getWriter();
					toClient.println("<html>");
					toClient.println("<title>Niza Hotel</title>");
					toClient.println("<h1>ERROR</h1>");
					toClient.println("<h4>No free rooms available.</h4>");
					toClient.println("<hr></hr>");
					toClient.println("Sorry " + nizacliente.user + ", unfortunately we are completely booked. Try again later. ");
					toClient.println("<p>Back to <a href=\"http://localhost:8080/PracticaFinalSCD/NizaCliente.html\"> Client Area</a></p>");
					toClient.println("</html>");
					toClient.close();
				}
				else	// Free rooms found
				{
					// Re-execute query so no data is missed 
					rs = st.executeQuery(sql);
					
					// Show available rooms to user
					PrintWriter toClient = response.getWriter();
					toClient.println("<html>");
					toClient.println("<title>Hotel Niza</title>");
					toClient.println("<body>");
					toClient.println("<h1>Hotel Niza: Rooms</h1>");
					toClient.println("<h4>The available rooms are displayed in the following list</h4>");
					toClient.println("<hr></hr><BR>");
					
					while (rs.next()) // Go through entire result set and print rooms
					{
						int room = rs.getInt("roomID");
						toClient.println("Room: "+ room +"<BR>");
					}
					
					toClient.println("<BR>Choose which available room you would like to book: ");
					// User must introduce which room they want to book
					// Confirmation redirects to booking servlet
					toClient.println("<form action=\"http://localhost:8080/PracticaFinalSCD/NizaBooking\" method=\"POST\">");
					toClient.println("<BR><BR> Room Number: <input type=int name=roomniza>");
					toClient.println("<input type=submit name=room value=\" Confirm room \">");
					toClient.println("</form>");
					toClient.println("<form action=\"http://localhost:8080/PracticaFinalSCD/NizaCliente.html\" method=\"POST\">");
					toClient.println("<input type=submit name=login value=\" Client Area \">");
					toClient.println("</form>");
					toClient.println("</body>");
					toClient.println("</html>");
					toClient.close();
				}
				
				// Close statements, result sets and DB connection
				st.close();
				rs.close();
				conn.close();
			}
			catch(Exception e){ e.printStackTrace(); }
			
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
