// FINAL PRACTICE
// NizaModify.java
// Code for servlet associated to modify client data
// by Telmo Martinez, Carolina Nolasco and Viktor Odriozola

import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;


@WebServlet("/NizaModify")
public class NizaModify extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public NizaModify() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// Obtain information from session
		HttpSession session = request.getSession(false);
		Cliente nizacliente = (Cliente)session.getAttribute("nizasession");
		
		// Obtain new introduced data 
		String new_username = request.getParameter("userniza");
		String new_password = request.getParameter("passniza");
		
		try
		{
			// Register driver and connect to DB
			Class.forName("com.mysql.cj.jdbc.Driver");
			String URL="jdbc:mysql://localhost:3306/PFinal";
			Connection conn = DriverManager.getConnection(URL,"root","scd");
			
			// Create statement
			Statement st = conn.createStatement();
		
			if(new_username.equals("") == false && new_password.equals("") == false)
			{
				// CASE 1: User wants to change both the username and the password
				// (both fields are filled)
				
				// Check whether the introduced username already exists
				String sql = "SELECT user FROM UsersNiza WHERE user = '" + new_username + "';";
				ResultSet rs = st.executeQuery(sql);
				
				if(!rs.next()) // User does not exist, update is possible
				{
					// Update both password and username in DB
					sql = "UPDATE UsersNiza SET user = ?, password = ? WHERE userID = ? ;";
					
					PreparedStatement SQLUpdateRecord = conn.prepareStatement(sql);
					SQLUpdateRecord.setString(1, new_username);
					SQLUpdateRecord.setString(2, new_password);					
					SQLUpdateRecord.setInt(3, nizacliente.id);
					
					SQLUpdateRecord.executeUpdate();
					SQLUpdateRecord.close();
					
					// Update both password and username in session
					nizacliente.user = new_username;
					nizacliente.pass = new_password;
					
					// Inform user and redirect to Login
					PrintWriter toClient = response.getWriter();
					toClient.println("<html>");
					toClient.println("<title>Niza Hotel</title>");
					toClient.println("<h1>Correct Update</h1>");
					toClient.println("<h4>Username and password were correctly updated.</h4>");
					toClient.println("<hr></hr>");
					toClient.println("You must now log into your account.");
					toClient.println("<p> Back to <a href=\"http://localhost:8080/PracticaFinalSCD/NizaLogin.html\"> login.</a></p>");
					toClient.println("</html>");
					toClient.close();
					
				}
				else	// User does exist, update not possible
				{
					// Inform user and redirect to modify data again and try a different username
					PrintWriter toClient = response.getWriter();
					toClient.println("<html>");
					toClient.println("<title>Niza Hotel</title>");
					toClient.println("<h1>Error</h1>");
					toClient.println("<h4>User already exists.</h4>");
					toClient.println("<hr></hr>");
					toClient.println("The user " + new_username + " already exists, please try again.");
					toClient.println("<a href=\"http://localhost:8080/PracticaFinalSCD/NizaModify.html\"> Return.</a>");
					toClient.println("</html>");
					toClient.close();
				}
				
				// Close result set
				rs.close();
				
			}
			else if(new_username.equals("") == false && new_password.equals("") == true)
			{
				// CASE 2: User only wants to update username 
				// (username field is filled, password field is left blank)
				
				// Check whether the introduced username already exists
				String sql = "SELECT user FROM UsersNiza WHERE user = '" + new_username + "';";
				ResultSet rs = st.executeQuery(sql);
				
				if(!rs.next()) // User does not exist, update is possible
				{
					// Update username in DB
					sql = "UPDATE UsersNiza SET user = ? WHERE userID = ? ;";
					
					PreparedStatement SQLUpdateRecord = conn.prepareStatement(sql);
					SQLUpdateRecord.setString(1, new_username);
					SQLUpdateRecord.setInt(2, nizacliente.id);
					
					SQLUpdateRecord.executeUpdate();
					SQLUpdateRecord.close();
					
					// Update username in session
					nizacliente.user = new_username;
					
					// Inform user and redirect to Login
					PrintWriter toClient = response.getWriter();
					toClient.println("<html>");
					toClient.println("<title>Niza Hotel</title>");
					toClient.println("<h1>Correct Update</h1>");
					toClient.println("<h4>Username was correctly updated.</h4>");
					toClient.println("<hr></hr>");
					toClient.println("You must now log in into your account.");
					toClient.println("<p> Back to <a href=\"http://localhost:8080/PracticaFinalSCD/NizaLogin.html\"> login.</a></p>");
					toClient.println("</html>");
					toClient.close();
					
				}
				else	// User does exist, update not possible
				{
					// Inform user and redirect to modify data again and try a different username
					PrintWriter toClient = response.getWriter();
					toClient.println("<html>");
					toClient.println("<title>Niza Hotel</title>");
					toClient.println("<h1>Error</h1>");
					toClient.println("<h4>User already exist.</h4>");
					toClient.println("<hr></hr>");
					toClient.println("The user " + new_username + " already exists, please try again.");
					toClient.println("<a href=\"http://localhost:8080/PracticaFinalSCD/NizaModify.html\"> Return.</a>");
					toClient.println("</html>");
					toClient.close();
				}
				
				// Close result set
				rs.close();
			}
			else if(new_username.equals("") == true && new_password.equals("") == false)
			{
				// CASE 3: User wants to update password
				// (username field is left blank, password field is filled)
				
				// Update password in DB
				String sql = "UPDATE UsersNiza SET password = ? WHERE userID = ? ;";
				
				PreparedStatement SQLUpdateRecord = conn.prepareStatement(sql);
				SQLUpdateRecord.setString(1, new_password);
				SQLUpdateRecord.setInt(2, nizacliente.id);
				
				SQLUpdateRecord.executeUpdate();
				SQLUpdateRecord.close();
				
				// Update password in session
				nizacliente.pass = new_password;
				
				// Inform user and redirect to login
				PrintWriter toClient = response.getWriter();
				toClient.println("<html>");
				toClient.println("<title>Niza Hotel</title>");
				toClient.println("<h1>Correct Update</h1>");
				toClient.println("<h4>Password was correctly updated.</h4>");
				toClient.println("<hr></hr>");
				toClient.println("You must now log in into your account.");
				toClient.println("<p> Back to <a href=\"http://localhost:8080/PracticaFinalSCD/NizaLogin.html\"> login.</a></p>");
				toClient.println("</html>");
				toClient.close();
				
			}
			else
			{
				// CASE 4: both fields are left blank
				
				// Inform user and redirect to client area
				PrintWriter toClient = response.getWriter();
				toClient.println("<html>");
				toClient.println("<title>Niza Hotel</title>");
				toClient.println("<h1>Error</h1>");
				toClient.println("<h4>Empty selection.</h4>");
				toClient.println("<hr></hr>");
				toClient.println("Nothing was introduced, please try again.");
				toClient.println("<p>Back to <a href=\"http://localhost:8080/PracticaFinalSCD/NizaCliente.html\"> Client Area.</a></p>");
				toClient.println("</html>");
				toClient.close();
				
			}
			
			// Close statement and DB connection
			st.close();
			conn.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
