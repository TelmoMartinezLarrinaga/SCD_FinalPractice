// FINAL PRACTICE
// NizaRegister.java
// Code for servlet associated to registration of new user
// by Telmo Martinez, Carolina Nolasco and Viktor Odriozola

import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;


@WebServlet("/NizaRegister")
public class NizaRegister extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public NizaRegister() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// Obtain session info
		HttpSession session = request.getSession(false);
		Cliente nizacliente = (Cliente)session.getAttribute("nizasession");
		String input_user = request.getParameter("userniza");
		String input_password = request.getParameter("passniza");
		
		if(input_user.equals("") == true || input_password.equals("") == true) // Both fields have to be non-empty
		{
			// Inform user and redirect to registration
			PrintWriter toClient = response.getWriter();
			toClient.println("<html>");
			toClient.println("<title>Niza Hotel</title>");
			toClient.println("<h1>Error</h1>");
			toClient.println("<h4>Invalid input.</h4>");
			toClient.println("<hr></hr>");
			toClient.println("Either the username or password have not been introduced, try again. ");
			toClient.println("<p>Back to <a href=\"http://localhost:8080/PracticaFinalSCD/NizaRegister.html\"> registration.</a></p>");
			toClient.println("</html>");
			toClient.close();
		}
		else
		{
			// Request from html introduced information
			nizacliente.user = input_user;
			nizacliente.pass = input_password;
			
			try 
			{
				// Register driver and connect to DB
				Class.forName("com.mysql.cj.jdbc.Driver");
				String URL="jdbc:mysql://localhost:3306/PFinal";
				Connection conn = DriverManager.getConnection(URL,"root","scd");
				
				// Create statement
				Statement st = conn.createStatement();
				
				// Check whether the introduced username already exists
				String sql = "SELECT user FROM UsersNiza WHERE user = '" + nizacliente.user + "';";
				ResultSet rs = st.executeQuery(sql);
				
				if(!rs.next()) // User does not exits, valid choice
				{
					// Introduce new user and corresponding password to DB
					PreparedStatement ps = conn.prepareStatement("INSERT INTO UsersNiza (user,password,role) VALUES(?,?,?)");
					ps.setString(1, nizacliente.user);
					ps.setString(2, nizacliente.pass);
					ps.setInt(3, 0);
					ps.executeUpdate();
					ps.close();
					
					// Inform user and redirect to Login
					PrintWriter toClient = response.getWriter();
					toClient.println("<html>");
					toClient.println("<title>Niza Hotel</title>");
					toClient.println("<h1>Confirmation</h1>");
					toClient.println("<h4>Correct Registration.</h4>");
					toClient.println("<hr></hr>");
					toClient.println("The user " + nizacliente.user + " has been registered correctly.");
					toClient.println("<p> Back to <a href=\"http://localhost:8080/PracticaFinalSCD/NizaLogin.html\"> login.</a></p>");
					toClient.println("</html>");
					toClient.close();
				}
				else // Username is in use, invalid username
				{
					// Inform user and redirect to registration
					PrintWriter toClient = response.getWriter();
					toClient.println("<html>");
					toClient.println("<title>Niza Hotel</title>");
					toClient.println("<h1>Error</h1>");
					toClient.println("<h4>User in use.</h4>");
					toClient.println("<hr></hr>");
					toClient.println("The user " + nizacliente.user + " is already in use, please try again.");
					toClient.println("<p>Back to <a href=\"http://localhost:8080/PracticaFinalSCD/NizaRegister.html\"> registration.</a></p>");
					toClient.println("</html>");
					toClient.close();
				}
				
				// Close statements, result sets and DB connection
				st.close();
				rs.close();
				conn.close();
			}
			catch (SQLException sqle)
			{
				sqle.printStackTrace();
			}
			catch(Exception e) 
			{
				e.printStackTrace();
			}
		}
	
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doGet(request, response);
	}

}
