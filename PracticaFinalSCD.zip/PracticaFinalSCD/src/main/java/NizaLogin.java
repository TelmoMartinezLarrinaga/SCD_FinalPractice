// FINAL PRACTICE
// NizaLogin.java
// Code for servlet associated to initial login 
// by Telmo Martinez, Carolina Nolasco and Viktor Odriozola

import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;


@WebServlet("/NizaLogin")
public class NizaLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public NizaLogin() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// Create session and client
		HttpSession session = request.getSession(true);
		Cliente nizacliente = new Cliente();
		
		// Obtain introduced username and password
		nizacliente.user = request.getParameter("userniza");
		nizacliente.pass = request.getParameter("passniza");
		
		// Obtain pressed button
		String send = request.getParameter("send");
		String register = request.getParameter("register");
		
		if(send != null) 	// If user requested to send information
		{
			try 
			{
				// Register driver and connect to database
				Class.forName("com.mysql.cj.jdbc.Driver");
				String URL="jdbc:mysql://localhost:3306/PFinal";
				Connection conn = DriverManager.getConnection(URL,"root","scd");
				
				// Create statement
				Statement st = conn.createStatement();
				
				// Find whether the introduced user exists
				String sql = "SELECT * FROM UsersNiza WHERE user = '" + nizacliente.user + "';";
				ResultSet rs = st.executeQuery(sql);
				
				if(!rs.next()) // User does not exist
				{
					// Inform user and redirect to Login
					PrintWriter toClient = response.getWriter();
					toClient.println("<html>");
					toClient.println("<title>Niza Hotel</title>");
					toClient.println("<h1>Error</h1>");
					toClient.println("<h4>The input data is incorrect. Please try again.</h4>");
					toClient.println("<hr></hr>");
					toClient.println("<p>Back to <a href=\"http://localhost:8080/PracticaFinalSCD/NizaLogin.html\"> login.</a></p>");
					toClient.println("</html>");
					toClient.close();
					
				}
				else // User does exist
				{
					// Find information on that user
					/*sql = "SELECT * FROM UsersNiza WHERE user = '" + nizacliente.user + "';";*/
					rs = st.executeQuery(sql);
					
					if (rs.next())
					{	
						// Check if the password is correct
						String db_pass = rs.getString("password");

						if(db_pass.equals(nizacliente.pass)) // Correct password
						{
							// Save information about the user in the session
							nizacliente.role = rs.getInt("role");
							nizacliente.id = rs.getInt("userID");
							
							// Act according to role and redirect
							if (nizacliente.role == 0) // User
							{
								response.sendRedirect("NizaCliente.html");
							}
							else // Administrator
							{
								response.sendRedirect("NizaAdmin");
							}
						}
						else // Incorrect password
						{
							// Inform user and redirect to Login
							PrintWriter toClient = response.getWriter();
							toClient.println("<html>");
							toClient.println("<title>Niza Hotel</title>");
							toClient.println("<h1>Error</h1>");
							toClient.println("<h4>Incorret password.</h4>");
							toClient.println("<hr></hr>");
							toClient.println("The password introduced for user " + nizacliente.user + " is incorrect, please try again.");
							toClient.println("<p> Back to <a href=\"http://localhost:8080/PracticaFinalSCD/NizaLogin.html\"> login.</a></p>");
							toClient.println("</html>");
							toClient.close();
						}
					}
				}
				
				// Close statements, result sets and DB connection
				st.close();
				rs.close();
				conn.close();
			}
			catch (SQLException sqle){ sqle.printStackTrace(); }
			catch(Exception e){ e.printStackTrace(); }
		}
		else if (register!=null) // If user requested to register
		{
			// Redirect to registration
			response.sendRedirect("NizaRegister.html");
		}
		
		// Assign name and object to session
		session.setAttribute("nizasession", nizacliente);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doGet(request, response);
		
	}

}
