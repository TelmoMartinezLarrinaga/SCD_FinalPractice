// FINAL PRACTICE
// Cliente.java
// Code for class Cliente.java
// by Telmo Martinez, Carolina Nolasco and Viktor Odriozola

/* Explanation of code
 * 
 * This is the class from which the objects associated to the sessions will stem from. 
 */

public class Cliente 
{
	int id;			// ID of user in DB
	String user;	// Username		
	String pass;	// Password
	int role;  		// 0 hotel user, 1 hotel admin
}
