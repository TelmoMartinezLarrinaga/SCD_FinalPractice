// FINAL PRACTICE
// NizaBooking.java
// Code for servlet associated to client booking
// by Telmo Martinez, Carolina Nolasco and Viktor Odriozola

import java.io.*;
import java.net.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;


@WebServlet("/NizaBooking")
public class NizaBooking extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public NizaBooking() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// Obtain session information
		HttpSession session = request.getSession(false);
		Cliente nizacliente = (Cliente)session.getAttribute("nizasession");
		
		// Obtain introduced room number
		String roomnumber = request.getParameter("roomniza");
		
		int room = 0;
		
		// Check if filled information is actually a number
		try 	
		{
			// If it is, save to value
			room = Integer.parseInt(roomnumber);
		}
		catch (NumberFormatException nfe)
		{
			// If not, inform user and redirect to client area
			PrintWriter toClient = response.getWriter();
			toClient.println("<html>");
			toClient.println("<title>Niza Hotel</title>");
			toClient.println("<h1>Error</h1>");
			toClient.println("<h4>Introduce corret room number.</h4>");
			toClient.println("<hr></hr>");
			toClient.println("<p>Back to <a href=\"http://localhost:8080/PracticaFinalSCD/NizaCliente.html\"> Client Area</a></p>");
			toClient.println("</html>");
			toClient.close();
		}
		
		// Filled information is valid, continue the process
		
		try 
		{
			// Register driver and connect to DB
			Class.forName("com.mysql.cj.jdbc.Driver");
			String URL="jdbc:mysql://localhost:3306/PFinal";
			Connection conn = DriverManager.getConnection(URL,"root","scd");
			
			// Create statement
			Statement st = conn.createStatement();
			
			// Check whether selected room is available or not
			String sql = "SELECT * FROM RoomsNiza WHERE roomID = " + room + ";";
			ResultSet rs = st.executeQuery(sql);
			
			if(rs.next())
			{
				if (rs.getInt("availability") == 0) // Room available, can book
				{
					// Update room to booked in DB and register which user is booking it
					sql = "UPDATE RoomsNiza SET availability = 1, userID = " + nizacliente.id + " WHERE roomID = ? ;";
					
					PreparedStatement SQLUpdateRecord = conn.prepareStatement(sql);
					SQLUpdateRecord.setInt(1, room);
					
					SQLUpdateRecord.executeUpdate();
					SQLUpdateRecord.close();
					
					// Inform the user and redirect to Client Area
					PrintWriter toClient = response.getWriter();
					toClient.println("<html>");
					toClient.println("<title>Niza Hotel</title>");
					toClient.println("<h1>Confirmation</h1>");
					toClient.println("<hr></hr>");
					toClient.println("Congratulations the room "+ room +" is correctly booked.");
					toClient.println("<p>Back to <a href=\"http://localhost:8080/PracticaFinalSCD/NizaCliente.html\"> Client Area</a></p>");
					toClient.println("</html>");
					toClient.close();
					
					// Inform Ministry of Tourism via socket connection
					
					// Obtain IP address
					InetAddress ip = InetAddress.getByName("localhost");
					// Client socket via port 5056
					Socket s = new Socket(ip, 5056);
					
		            // Obtaining input and out streams
		            DataInputStream dis = new DataInputStream(s.getInputStream());
		            DataOutputStream dos = new DataOutputStream(s.getOutputStream());
		            
		            // Calculate number of visitors in hotel and max number of visitors 
		            // NOTE: number of visitors coincides with number of rooms
		            sql = "SELECT * FROM RoomsNiza;";
		            rs = st.executeQuery(sql);
		            int num_visitors = 0, max_visitors = 0;
		            
		            while (rs.next()) 
		            {
		            	max_visitors ++;
		            	if (rs.getInt("availability") == 1) num_visitors++;
		            }
		            
		            if (num_visitors == max_visitors)	
		            	// Inform that hotel is complete
		            	dos.writeUTF("Hotel Niza \nNew visitor. Hotel completely booked. Current number of visitors =  " + num_visitors);
		            else	
		            	// Inform that a new visitor is in the hotel
		            	dos.writeUTF("Hotel Niza \nNew visitor. Current number of visitors =  " + num_visitors);
		            
		            // Send command to close connection and close socket connection
		            dos.writeUTF("Closing connection ...");
		            s.close();
				}
				else	// Room unavailable, cannot book
				{
					// Inform user and redirect to Client Area
					PrintWriter toClient = response.getWriter();
					toClient.println("<html>");
					toClient.println("<title>Niza Hotel</title>");
					toClient.println("<h1>Error</h1>");
					toClient.println("<h4>Update was not possible.</h4>");
					toClient.println("<hr></hr>");
					toClient.println("The room "+ room +" is already booked. Please try again");
					toClient.println("<p>Back to <a href=\"http://localhost:8080/PracticaFinalSCD/NizaCliente.html\"> Client Area</a></p>");
					toClient.println("</html>");
					toClient.close();
				}
			}
			else
			{
				// Inform user and redirect to Client Area
				PrintWriter toClient = response.getWriter();
				toClient.println("<html>");
				toClient.println("<title>Niza Hotel</title>");
				toClient.println("<h1>Error</h1>");
				toClient.println("<h4>Introduced room number does not exist.</h4>");
				toClient.println("<hr></hr>");
				toClient.println("<p>Back to <a href=\"http://localhost:8080/PracticaFinalSCD/NizaCliente.html\"> Client Area</a></p>");
				toClient.println("</html>");
				toClient.close();
			}
				
				
			
			// Close statement, result set and DB connection
			rs.close();
			st.close();
			conn.close();
		}
		catch(Exception e){e.printStackTrace();}	
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
