// FINAL PRACTICE
// CodinaAdmin.java
// Code for servlet associated to admin area
// by Telmo Martinez, Carolina Nolasco and Viktor Odriozola

import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

@WebServlet("/CodinaAdmin")
public class CodinaAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public CodinaAdmin() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		// Obtain information from session
		HttpSession session = request.getSession(false);
		Cliente codinacliente = (Cliente)session.getAttribute("codinasession");
		
		try
		{
			// Register driver and connect to DB
			Class.forName("com.mysql.cj.jdbc.Driver");
			String URL="jdbc:mysql://localhost:3306/PFinal";
			Connection conn = DriverManager.getConnection(URL,"root","scd");
			
			// Create statement
			Statement st = conn.createStatement();
			
			// Select all rooms
			String sql = "SELECT * FROM RoomsCodina;"; 
			ResultSet rs = st.executeQuery(sql);
			
			// Print free rooms and their status for admin to see
			PrintWriter toClient = response.getWriter();
			toClient.println("<html>");
			toClient.println("<title>Codina Hotel</title>");
			toClient.println("<h1>Codina Hotel Rooms:</h1>");
			toClient.println("<h4>The hotel Codina rooms and their status are:</h4>");
			toClient.println("<hr></hr><BR>");
			toClient.println("<body>");
			
			
			while (rs.next())
			{
				int room = rs.getInt("roomID");
				
				if(rs.getInt("availability")==0) // Room is available
				{
					toClient.print("Room: "+ room + " , Status: available.<BR>");
				}
				else // Room is unavailable
				{
					toClient.print("Room: "+ room + " , Status: unavailable.<BR>");
				}
			}
			
			toClient.println("<BR><hr></hr><BR>");
			toClient.println("Choose which unavailable room you would like to free: ");
			// Introduce which room the admin wants to make available and redirect to Admin Booking
			toClient.println("<form action=\"http://localhost:8080/PracticaFinalSCDCodina/CodinaBookingAdmin\" method=\"POST\">");
			toClient.println("<BR><BR> Room Number: <input type=int name=roomcodina>");
			toClient.println("<input type=submit name=room value=\" Confirm action. \">");
			toClient.println("</form>");
			// Give option to redirect to login
			toClient.println("<form action=\"http://localhost:8080/PracticaFinalSCDCodina/CodinaLogin.html\" method=\"POST\">");
			toClient.println("<input type=submit name=login value=\" Back to login. \">");
			toClient.println("</form>");
			toClient.println("</body>");
			toClient.println("</html>");
			toClient.close();
			
			// Close statement, result set and DB connection 
			st.close();
			rs.close();
			conn.close();
			
		}
		catch(Exception e){ e.printStackTrace(); }
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
