// FINAL PRACTICE
// CodinaBookingAdmin.java
// Code for servlet associated to booking admin
// by Telmo Martinez, Carolina Nolasco and Viktor Odriozola

import java.io.*;
import java.net.InetAddress;
import java.net.Socket;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

@WebServlet("/CodinaBookingAdmin")
public class CodinaBookingAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public CodinaBookingAdmin() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		// Obtain information from session
		HttpSession session = request.getSession(false);
		Cliente codinacliente = (Cliente)session.getAttribute("codinasession");
		
		// Obtain introduced room number
		String roomnumber = request.getParameter("roomcodina");
		
		int room = 0;
		
		// Check if filled information is actually a number
		try 	
		{
			// If it is, save to value
			room = Integer.parseInt(roomnumber);
		}
		catch (NumberFormatException nfe)
		{
			// If not, inform user and redirect to admin area
			PrintWriter toClient = response.getWriter();
			toClient.println("<html>");
			toClient.println("<title>Codina Hotel</title>");
			toClient.println("<h1>Erorr</h1>");
			toClient.println("<h4>Introduce correct room number.</h4>");
			toClient.println("<hr></hr>");
			toClient.println("Sorry , no correct room number was introduced ");
			toClient.println("<p> Back to<a href=\"http://localhost:8080/PracticaFinalSCDCodina/CodinaAdmin\"> Admin Area.</a></p>");
			toClient.println("</html>");
			toClient.close();
		}
		
		// Filled information is valid, continue the process
		
		try
		{
			// Register driver and connect to DB
			Class.forName("com.mysql.cj.jdbc.Driver");
			String URL="jdbc:mysql://localhost:3306/PFinal";
			Connection conn = DriverManager.getConnection(URL,"root","scd");
			
			// Create statement
			Statement st = conn.createStatement();
			
			// Check whether selected room is available or not
			String sql = "SELECT * FROM RoomsCodina WHERE roomID = " + room + ";";
			ResultSet rs = st.executeQuery(sql);
			
			if(rs.next())
			{
				if (rs.getInt("availability") == 1) // Room is available, can change status
				{
					// Update availability in DB
					sql = "UPDATE RoomsCodina SET availability = 0, userID = NULL WHERE roomID = ? ;";
					
					PreparedStatement SQLUpdateRecord = conn.prepareStatement(sql);
					SQLUpdateRecord.setInt(1, room);
					
					SQLUpdateRecord.executeUpdate();
					SQLUpdateRecord.close();
					
					// Inform admin and redirect to Admin Area
					PrintWriter toClient = response.getWriter();
					toClient.println("<html>");
					toClient.println("<title>Codina Hotel</title>");
					toClient.println("<h1>Confirmation</h1>");
					toClient.println("<hr></hr>");
					toClient.println("The room "+ room +" is correctly updated.");
					toClient.println("<p> Back to<a href=\"http://localhost:8080/PracticaFinalSCDCodina/CodinaAdmin\"> Admin Area.</a></p>");
					toClient.println("</html>");
					toClient.close();
					
					// Inform Ministry of Tourism via socket connection
					
					// Obtain IP address
					InetAddress ip = InetAddress.getByName("localhost");
					// Client socket via port 5056
					Socket s = new Socket(ip, 5056);
					
		            // Obtaining input and out streams
		            DataInputStream dis = new DataInputStream(s.getInputStream());
		            DataOutputStream dos = new DataOutputStream(s.getOutputStream());
		            
		            // Calculate number of visitors in hotel 
		            // NOTE: number of visitors coincides with number of rooms
		            sql = "SELECT * FROM RoomsCodina;";
		            rs = st.executeQuery(sql);
		            int num_visitors = 0;
		            
		            while (rs.next()) 
		            {
		            	if (rs.getInt("availability") == 1) num_visitors++;
		            }
		            
		            // Inform that a visitor has left the hotel	
	            	dos.writeUTF("Hotel Codina \nVisitor left. Current number of visitors =  " + num_visitors);
	            	
	            	// Send command to close connection and close socket connection
		            dos.writeUTF("Closing connection ...");
		            s.close();
				}
				else  // Room available, cannot change status
				{
					// Inform Admin and redirect to Admin Area
					PrintWriter toClient = response.getWriter();
					toClient.println("<html>");
					toClient.println("<title>Codina Hotel</title>");
					toClient.println("<h1>Error</h1>");
					toClient.println("<h4>Update was not possible.</h4>");
					toClient.println("<hr></hr>");
					toClient.println("The room "+ room +" is already available. Please try again");
					toClient.println("<p> Back to<a href=\"http://localhost:8080/PracticaFinalSCDCodina/CodinaAdmin\"> Admin Area.</a></p>");
					toClient.println("</html>");
					toClient.close();
				}
			}
			else
			{
				// Inform user and redirect to Client Area
				PrintWriter toClient = response.getWriter();
				toClient.println("<html>");
				toClient.println("<title>Codina Hotel</title>");
				toClient.println("<h1>Error</h1>");
				toClient.println("<h4>Introduced room number does not exist.</h4>");
				toClient.println("<hr></hr>");
				toClient.println("<p>Back to <a href=\"http://localhost:8080/PracticaFinalSCDCodina/CodinaAdmin\"> Admin Area</a></p>");
				toClient.println("</html>");
				toClient.close();
			}
			
			// Close statement, result set and DB connection
			rs.close();
			st.close();
			conn.close();
		}
		catch(Exception e){e.printStackTrace();}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
