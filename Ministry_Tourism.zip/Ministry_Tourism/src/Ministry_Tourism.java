// FINAL PRACTICE
// Ministry_Tourism.java
// Code for server of Ministry of Tourism
// by Telmo Martinez, Carolina Nolasco and Viktor Odriozola

/* Explanation of flow of code
 * 
 * The goal of the ministry of tourism is to receive and show via console the current occupancy of the hotels.
 * It is constantly listening for new information from any hotel, and when it receives an update, it lets the user know 
 * via console. Once the hotel is fully booked, it is also shown.
 */

import java.io.*;
import java.net.*;
import java.sql.*;

public class Ministry_Tourism 
{
	 public static void main(String[] args) throws Exception
	 {
	      // SOCKET CONNECTION
	      // Server listening on port 5056
	      ServerSocket ss = new ServerSocket(5056);
	      
	      System.out.println("Start listening...");

	      // Run infinite loop to get client request
	      while (true)
	      {
	    	  Socket s = null; 	
	    	  String received;	// String for receiving information from client
	    	  
	    	  try
	    	  {
	              // Socket object to receive incoming client requests
	              s = ss.accept();

	              // Successful connection                 
	              System.out.println("A new hotel is connected : " + s);

	              // Obtaining input and output data streams
	              DataInputStream dis = new DataInputStream(s.getInputStream());
	              DataOutputStream dos = new DataOutputStream(s.getOutputStream());

	              // Receiving information
	              while (true)
	              {
		              received =  dis.readUTF();
		              if(received.equals("Closing connection ...")) // Instruction to finish connection
            		  {
		            	  // Close socket and break from loop
		            	  System.out.println(received + "\n");
		            	  s.close();
		            	  break;
            		  }
		              else System.out.println(received + "\n");		// othw. output change in hotel occupancy
	              }

	    	  }
	    	  catch(Exception e)
	    	  {
	              s.close();
	              e.printStackTrace();
	    	  }
	      }
	}
 }




